#include "mbed.h"

DigitalOut myled(LED1);
double dotDuration = 0.5;
int dashDuration = 1;
int blankDuration = 2;
int endDuration = 4;

void dot(){
myled = 1; // LED is ON
        wait(dotDuration);
        myled = 0; // LED is OFF
        wait(dotDuration);
}

void dash(){
myled = 1; // LED is ON
        wait(dashDuration);
        myled = 0; // LED is OFF
        wait(dotDuration);
}

void blank(){
    wait(blankDuration
);
}

void end(){
    wait(blankDuration
);
}

int main() {
//erik
    while(1) {
        dot();//E
        blank();
        dot();//R
        dash();
        dot();
        blank();
        dot();//I
        dot();
        blank();
        dash();//K
        dot();
        dash();
        end();
    }
}
